package CompositePatter;

public class Triangle extends CompositeShape {
    int x, y, base, height;

    public Triangle(int x, int y, int base, int height) {
        this.x = x;
        this.y = y;
        this.base = base;
        this.height = height;
    }

	@Override
	public void buildShape() {
		// TODO Auto-generated method stub
		addShape(new Line(x, y, x, x+height));
        addShape(new Line(x, y, x+base, height));
        addShape(new Line(x, y+height, x+base, height));
	}
}

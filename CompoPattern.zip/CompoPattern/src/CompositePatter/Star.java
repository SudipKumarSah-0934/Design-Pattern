package CompositePatter;

public class Star extends CompositeShape{
	int x, y, base, height;

	public Star(int x, int y, int base, int height) {
		this.x = x;
		this.y = y;
		this.base = base;
		this.height = height;
	}


	@Override
	public void buildShape() {
		// TODO Auto-generated method stub
		addShape(new Line(x, y, x+base/2, y+height));
		addShape(new Line(x, y, x+base, y));
		addShape(new Line(x+base/2, y+height, x+base, y));

		addShape(new Line(x+base/2, y-height/2, x+base, y+height/2));
		addShape(new Line(x+base/2, y-height/2, x, y+height/2));
		addShape(new Line(x, y+height/2, x+base, y+height/2));
	}

}

